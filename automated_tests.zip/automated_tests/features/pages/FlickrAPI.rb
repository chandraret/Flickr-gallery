Class FlickrAPI
include PageObject

page_url "https://api.flickr.com/services/feeds/photos_public.gne?format=json&nojsoncallback=1&tags%20=<%=params[:text]%>"

def get_titles
	tabledata.rows.each do |row|
  	row.cells.each do |cell|
    puts cell.text          
 end
 end