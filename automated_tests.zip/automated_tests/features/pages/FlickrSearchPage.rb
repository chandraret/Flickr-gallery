class FlickrSearchPage
	include PageObject
	page_url "https://www.flickr.com/search/<%=params[:text]%>"

	text_field(:search_box, :id => "search-field")
	div(:results, :id => "yui_3_16_0_1_1488188249659_4203")

	def fill_searchBox(text)
	self.search_box.send_keys("#{text}")
	end

	def get_titles
	self.results
	tabledata.rows.each do |row|
  	row.cells.each do |cell|
    puts cell.text          
  	end
  	end