Given(/^I visit "(.*?)"$/) do |page_name|
if page_name == "flickr gallery page"
visit FlickrSearchPage {:using_params => "?text="}
end
if page_name == "flickr API"
visit FlickrAPI
end

When(/^I search for "(.*?)"$/) do |text|
on FlickrSearchPage do |page|
page.fill_searchBox(text)
end
end

Then(/^I should get image titles$/)
on FlickrSearchPage do |page|
@a = page.get_titles
end
end

Then(/^I collect the titles from the API response$/)
on FlickrAPI do |page|
@b = page.get_titles
end

Given(/^I comapare the scenario1 and scenario2 results$/)
# @a are results from scenario1
# @b are results from scenario2
end

Then(/^comparision results should match$/)
if @a == @b
puts "The results from scenario1 and scenario2 have matched"
else
puts "The results don't match, please check the query string"
end
end
